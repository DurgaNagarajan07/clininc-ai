import React, { useState, useEffect, useCallback } from 'react';
import { Mic, Send, Trash2, Languages, MicOff } from 'lucide-react';
import { cn } from '../lib/utils';

interface ConversationInputProps {
  onGenerate: (text: string) => void;
  isLoading: boolean;
}

// Extend Window interface for WebkitSpeechRecognition
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

export const ConversationInput: React.FC<ConversationInputProps> = ({ onGenerate, isLoading }) => {
  const [text, setText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-IN'; // Good for English/Indian regional language mixing

      recognitionInstance.onresult = (event: any) => {
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        
        if (finalTranscript) {
          setText(prev => (prev ? prev + ' ' + finalTranscript : finalTranscript));
        }
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, []);

  const toggleListening = useCallback(() => {
    if (!recognition) {
       alert("Speech recognition is not supported in this browser. Please use Chrome.");
       return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  }, [recognition, isListening]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isListening) recognition?.stop();
    if (text.trim() && !isLoading) {
      onGenerate(text);
    }
  };

  const handleClear = () => {
    setText('');
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full">
          <Languages className="w-4 h-4 text-slate-600" />
          <span className="text-[10px] font-semibold text-slate-600 uppercase tracking-widest leading-none">
            Multilingual Support Active
          </span>
        </div>
        {text && (
          <button 
            type="button"
            onClick={handleClear}
            className="flex items-center gap-1.5 text-[10px] font-semibold text-rose-600 hover:text-rose-700 uppercase tracking-widest transition-colors"
          >
            <Trash2 className="w-3 h-3" />
            Clear
          </button>
        )}
      </div>

      <div className="relative flex-1">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Start speaking or paste dialogue here..."
          className="w-full h-full p-5 text-sm transition-all bg-white border border-slate-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 placeholder:text-slate-400"
        />
        
        <div className="absolute bottom-4 right-4">
          <button
            type="button"
            onClick={toggleListening}
            className={cn(
              "flex items-center gap-2 px-4 py-2 text-[10px] uppercase font-bold tracking-widest rounded-xl border transition-all duration-300 shadow-sm",
              isListening 
                ? "bg-rose-50 border-rose-200 text-rose-600 animate-pulse" 
                : "bg-white border-slate-200 text-slate-600 hover:border-blue-600"
            )}
          >
            {isListening ? (
              <>
                <MicOff className="w-3.5 h-3.5" />
                Stop Listening
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5" />
                Start Voice capture
              </>
            )}
          </button>
        </div>
      </div>

      <button
        onClick={handleSubmit}
        disabled={isLoading || !text.trim()}
        className={cn(
          "w-full py-4 rounded-xl font-bold text-sm tracking-widest uppercase transition-all flex items-center justify-center gap-2",
          text.trim() && !isLoading 
            ? "bg-slate-900 text-white hover:bg-black shadow-lg hover:shadow-xl active:scale-[0.98]" 
            : "bg-slate-200 text-slate-400 cursor-not-allowed"
        )}
      >
        {isLoading ? (
          <div className="w-5 h-5 border-2 rounded-full border-white/30 border-t-white animate-spin" />
        ) : (
          <>
            <Send className="w-4 h-4" />
            Process Note
          </>
        )}
      </button>
      
      <p className="text-[10px] text-center text-slate-400 font-bold uppercase tracking-widest">
        Clinical validation required before final sign-off
      </p>
    </div>
  );
};
