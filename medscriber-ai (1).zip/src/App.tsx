/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ConversationInput } from './components/ConversationInput';
import { NoteDisplay } from './components/NoteDisplay';
import { Signup } from './components/Signup';
import { generateClinicalNotes, ClinicalNotes } from './services/gemini';
import { Stethoscope, BookOpen, ShieldCheck, HelpCircle, History as HistoryIcon, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface UserData {
  fullName: string;
  phone: string;
  role: 'doctor' | 'patient';
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);
  const [notes, setNotes] = useState<ClinicalNotes | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignup = (data: UserData) => {
    setUser(data);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setNotes(null);
  };

  const handleGenerate = async (conversation: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await generateClinicalNotes(conversation);
      setNotes(result);
    } catch (err) {
      setError('An error occurred while generating notes. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isAuthenticated) {
    return <Signup onSignup={handleSignup} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-4 h-18 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold">
              MD
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900">MedScriber AI</h1>
              <p className="text-xs text-slate-500 font-medium tracking-wide">
                {user?.role === 'doctor' ? 'Clinical Workspace' : 'Patient History'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden lg:block text-right">
              <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">{user?.fullName}</p>
              <p className="text-sm font-semibold capitalize">{user?.role} Access</p>
            </div>
            <div className="h-8 w-[1px] bg-slate-200 mx-2 hidden md:block"></div>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full border border-slate-200 hover:bg-rose-50 hover:border-rose-200 hover:text-rose-600 transition-all text-xs font-bold uppercase tracking-wide text-slate-700"
            >
              <LogOut className="w-3 h-3" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Input */}
          <div className="lg:col-span-4 flex flex-col space-y-6 no-print">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[600px]">
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-blue-600 text-lg">●</span>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Conversation Input
                  </h2>
                </div>
                <p className="text-sm font-medium text-slate-600">Transcribe live or paste history.</p>
              </div>
              <div className="flex-1">
                <ConversationInput onGenerate={handleGenerate} isLoading={isLoading} />
              </div>
            </div>

            <div className="bg-blue-900 text-blue-100 p-5 rounded-2xl border border-blue-800 shadow-inner relative overflow-hidden">
               <div className="absolute left-0 top-0 h-full w-1 bg-blue-400"></div>
               <p className="text-[10px] font-bold uppercase tracking-widest text-blue-400 mb-2">Security Protocol</p>
               <p className="text-xs leading-relaxed opacity-90">
                 End-to-end encrypted processing. HIPAA/GDPR compliant infrastructure enabled.
               </p>
            </div>
          </div>

          {/* Right Column: Output */}
          <div className="lg:col-span-8 flex flex-col">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <span className="text-blue-600 text-lg">●</span>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Structured Outcome
                  </h2>
                </div>
                {isLoading && (
                  <div className="flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-600 rounded-full border border-blue-100">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Processing</span>
                  </div>
                )}
              </div>

              <AnimatePresence mode="wait">
                {error ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-6 bg-rose-50 border border-rose-100 rounded-2xl text-rose-700 text-sm flex items-start gap-3"
                  >
                    <HelpCircle className="w-5 h-5 shrink-0" />
                    <div>
                      <p className="font-bold uppercase tracking-wider mb-1">Processing Error</p>
                      <p>{error}</p>
                    </div>
                  </motion.div>
                ) : (
                  <NoteDisplay notes={notes} isLoading={isLoading} />
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="p-6 border-t border-slate-200 bg-white no-print">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] gap-4">
          <div className="flex items-center gap-4">
             <span>Linguistics Engine: Mixed Multi-Modal</span>
             <span className="text-slate-200">|</span>
             <span>Status: Verified</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
            <span>AI Model Cluster: Clinical-v4.2</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

