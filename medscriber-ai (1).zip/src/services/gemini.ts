import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface ClinicalNotes {
  patientSymptoms: string;
  durationOfIllness: string;
  medicalHistory: string;
  doctorObservations: string;
  possibleDiagnosis: string;
  medicationsMentioned: string;
  followUpInstructions: string;
  redFlags: string;
  missingInformation: string;
}

const SYSTEM_PROMPT = `You are an AI medical documentation assistant. 
Your job is to convert doctor–patient conversations into structured clinical notes and analyze clinical risk.

Rules:
- Do NOT invent or assume medical details.
- If information is not given, write "Not provided".
- Support multilingual input (Tamil, Hindi, English, mixed speech).
- Convert informal speech into proper medical terminology.
- Keep output clear, structured, and professional.
- Identify and highlight RED FLAGS such as chest pain, breathing difficulty, high fever, severe weakness, prolonged illness.

You must extract the information exactly into these categories:
1. Patient Symptoms
2. Duration of Illness
3. Medical History
4. Doctor Observations
5. Possible Diagnosis (only if clearly mentioned, otherwise state 'Not provided')
6. Medications Mentioned
7. Follow-up Instructions
8. Red Flags (Highlight any high-risk symptoms or concerns)
9. Missing Information / Questions Not Asked`;

export async function generateClinicalNotes(conversation: string): Promise<ClinicalNotes> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            { text: conversation }
          ]
        }
      ],
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            patientSymptoms: { type: Type.STRING, description: "Extract patient symptoms" },
            durationOfIllness: { type: Type.STRING, description: "Extract duration of illness" },
            medicalHistory: { type: Type.STRING, description: "Extract medical history" },
            doctorObservations: { type: Type.STRING, description: "Extract doctor observations" },
            possibleDiagnosis: { type: Type.STRING, description: "Extract possible diagnosis if mentioned" },
            medicationsMentioned: { type: Type.STRING, description: "Extract medications mentioned" },
            followUpInstructions: { type: Type.STRING, description: "Extract follow-up instructions" },
            redFlags: { type: Type.STRING, description: "Identify and highlight red flags or high-risk symptoms" },
            missingInformation: { type: Type.STRING, description: "Identify missing information or questions not asked" },
          },
          required: [
            "patientSymptoms",
            "durationOfIllness",
            "medicalHistory",
            "doctorObservations",
            "possibleDiagnosis",
            "medicationsMentioned",
            "followUpInstructions",
            "redFlags",
            "missingInformation"
          ]
        }
      }
    });

    const text = response.text || "{}";
    return JSON.parse(text) as ClinicalNotes;
  } catch (error) {
    console.error("Error generating clinical notes:", error);
    throw error;
  }
}
